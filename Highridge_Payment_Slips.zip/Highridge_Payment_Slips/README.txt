Highridge Construction Company - Payment Slips

This program generates salary reports for 400 employees.

Python:
- File: Highridge_Construction_Payments.py
- Run using: python highridge_Construction_Payments.py

R:
- File: Highridge_Construction_Payments.R
- Run using: source("Highridge_Construction_Payments.R")

Logic:
- Each worker is randomly given a salary and gender.
- Based on the salary and gender:
  * If salary > 10,000 and < 20,000, level is "A1"
  * If salary > 7,500 and < 30,000 AND gender is Female, level is "A5-F"
